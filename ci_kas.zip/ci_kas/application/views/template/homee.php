
<br>
<br>

<!-- <div class="row">
						<div class="col-sm-6 col-md-3">
						</div>
						<div class="col-sm-6 col-md-3">
							<div class="card card-stats card-primary card-round">
								<div class="card-body">
									<div class="row">
										<div class="col-5">
											<div class="icon-big text-center">
												<i class="fa fa-credit-card"></i>
											</div>
										</div>
										<div class="col-7 col-stats">
											<div class="numbers">
												<a href="<?= site_url('home/laporan') ;?>">
												<p class="card-category">Laporan Keuangan</p>
												<h4 class="card-title"></h4>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">
							<div class="card card-stats card-info card-round">
								<div class="card-body">
									<div class="row">
										<div class="col-5">
											<div class="icon-big text-center">
												<i class="far fa-edit"></i>
											</div>
										</div>
										<div class="col-7 col-stats">
											<div class="numbers">
											<a href="<?= site_url('home/tambah') ;?>">
												<p class="card-category">Input Penerimaan</p>
												<h4 class="card-title"></h4>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">
						</div>
						<div class="col-sm-6 col-md-3">
						</div>
						<div class="col-sm-6 col-md-3">
							<div class="card card-stats card-success card-round">
								<div class="card-body ">
									<div class="row">
										<div class="col-5">
											<div class="icon-big text-center">
												<i class="far fa-edit"></i>
											</div>
										</div>
										<div class="col-7 col-stats">
											<div class="numbers">
											<a href="<?= site_url('home/kurang') ;?>">
												<p class="card-category">Input Pengeluaran</p>
												<h4 class="card-title"></h4>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">
							<div class="card card-stats card-primary card-round">
								<div class="card-body ">
									<div class="row">
										<div class="col-5">
											<div class="icon-big text-center">
												<i class="fa fa-search"></i>
											</div>
										</div>
										<div class="col-7 col-stats">
											<div class="numbers">
											<a href="<?= site_url('home/pencarian') ;?>">
												<p class="card-category">Pencarian</p>
												<h4 class="card-title"></h4>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">
						</div>
						<div class="col-sm-6 col-md-3">
							</div>
																				<div class="col-sm-6 col-md-3">
																					<div class="card card-stats card-info card-round">
																						<div class="card-body">
																							<div class="row">
																								<div class="col-5">
																									<div class="icon-big text-center">
																										<i class="far fa-folder-open"></i>
																									</div>
																								</div>
																								<div class="col-7 col-stats">
																									<div class="numbers">
																									<a href="<?= site_url('home/data2') ;?>">
																										<p class="card-category">Data Kas</p>
																										<h4 class="card-title"></h4>
																									</a>
																									</div>
																								</div>
																							</div>
																						</div>
																					</div>
																				</div>
								<div class="col-sm-6 col-md-3">
									<div class="card card-stats card-success card-round">
										<div class="card-body">
											<div class="row">
												<div class="col-5">
											<div class="icon-big text-center">
												<i class="far fa-folder-open"></i>
											</div>
										</div>
										<div class="col-7 col-stats">
											<div class="numbers">
												<a href="<?= site_url('home/data1') ;?>">
													<p class="card-category">Data User</p>
												<h4 class="card-title"></h4>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">
						</div>
						<div class="col-sm-6 col-md-3">
						</div>
						<div class="col-sm-6 col-md-6">
							<div class="card card-stats card-secondary card-round">
								<div class="card-body ">
									<div class="row">
										<div class="col-5">
											<div class="icon-big text-center">
												<i class="fas fa-chart-line"></i>
											</div>
										</div>
										<div class="col-7 col-stats">
											<div class="numbers">
											<a href="<?= site_url('home/chart1') ;?>">
												<p class="card-category">Grafik</p>
												<h4 class="card-title"></h4>
												</a>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="col-sm-6 col-md-3">
						</div>
</div> -->